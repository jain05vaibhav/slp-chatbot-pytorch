import logging
import os
import time
from contextlib import asynccontextmanager
from typing import Optional, List, Dict, Any
from fastapi import FastAPI, HTTPException, Request, Header, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

# Setup structured logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("voxai.server")

# Load .env variables if python-dotenv is present
try:
    from dotenv import load_dotenv
    load_dotenv()
    logger.info(".env file loaded successfully.")
except ImportError:
    pass

from model.inference import get_engine, GROQ_AVAILABLE
from model.admin_security import get_admin_manager, INTENTS_PATH

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: initialize inference engine
    logger.info("Starting VoxAI Web Server...")
    engine = get_engine()
    logger.info(f"Inference engine ready. Vocabulary: {len(engine.all_words)} features, Intents: {len(engine.tags)}.")
    yield
    # Shutdown: clean up if necessary
    logger.info("Shutting down VoxAI Web Server...")

app = FastAPI(
    title="VoxAI - Voice-Enabled AI Chatbot API",
    description="Deep Learning-based Voice Assistant with Speech Recognition, PyTorch Intent Classification & Groq LLM integration",
    version="1.2.0",
    lifespan=lifespan
)

# Configure CORS safely
cors_origins_env = os.getenv("CORS_ORIGINS", "*")
allowed_origins = [o.strip() for o in cors_origins_env.split(",") if o.strip()]
# Under CORS specs, allow_credentials=True cannot be used with wildcard ["*"]
allow_creds = allowed_origins != ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=allow_creds,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request schema with field validation
class ChatRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=1000, description="User voice or text prompt")
    use_groq: Optional[bool] = Field(False, description="Whether to use Groq LLM for vocalization")
    groq_api_key: Optional[str] = Field(None, max_length=200, description="Optional per-request Groq API key")
    client_id: Optional[str] = Field(None, max_length=100, description="Persistent visitor identity")
    session_id: Optional[str] = Field(None, max_length=100, description="Current session/visit identifier")
    user_agent_label: Optional[str] = Field(None, max_length=200, description="Browser/device metadata")

# Admin Master Schemas
class AdminLoginRequest(BaseModel):
    password: str = Field(..., min_length=1, max_length=200, description="Master admin password")

class AdminPasswordChangeRequest(BaseModel):
    old_password: str = Field(..., min_length=1, max_length=200, description="Current master password")
    new_password: str = Field(..., min_length=8, max_length=200, description="New master password (min 8 chars)")

class AdminConfigUpdateRequest(BaseModel):
    confidence_threshold: Optional[float] = Field(None, ge=0.05, le=0.99, description="Confidence threshold (0.05 - 0.99)")
    maintenance_mode: Optional[bool] = Field(None, description="System maintenance mode toggle")
    custom_system_prompt: Optional[str] = Field(None, description="Custom voice synthesis system prompt")
    default_engine: Optional[str] = Field(None, description="Default engine (groq or pytorch)")
    groq_api_key: Optional[str] = Field(None, max_length=200, description="Global Groq API key")

class AdminIntentsUpdateRequest(BaseModel):
    intents: List[Dict[str, Any]] = Field(..., description="Full intents dataset array")

class AdminBanRequest(BaseModel):
    client_id: str = Field(..., min_length=1, max_length=100)
    client_ip: Optional[str] = Field(None, max_length=50)
    reason: Optional[str] = Field("Administrative policy violation", max_length=300)

class AdminUnbanRequest(BaseModel):
    client_id: str = Field(..., min_length=1, max_length=100)

class AdminBroadcastRequest(BaseModel):
    enabled: bool = Field(...)
    message: str = Field(..., max_length=500)

class AdminIntercomRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=1000)

def verify_admin_token(
    authorization: Optional[str] = Header(None),
    x_admin_token: Optional[str] = Header(None)
) -> str:
    """FastAPI dependency: verifies cryptographic HMAC admin session token."""
    token = authorization or x_admin_token
    admin_mgr = get_admin_manager()
    if not token or not admin_mgr.verify_token(token):
        raise HTTPException(
            status_code=401,
            detail="Unauthorized: Access denied. Master cryptographic session token is invalid or expired."
        )
    return token

# Serve static frontend files
static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.get("/", response_class=HTMLResponse)
async def serve_index():
    index_path = os.path.join(static_dir, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return HTMLResponse("<h1>VoxAI Chatbot API Server Running</h1><p>Frontend static files loading...</p>")

@app.get("/api/health")
async def health_check():
    engine = get_engine()
    groq_key_set = bool(os.getenv("GROQ_API_KEY"))
    return {
        "status": "healthy",
        "model_loaded": engine.is_loaded,
        "vocabulary_size": len(engine.all_words),
        "intents_count": len(engine.tags),
        "groq_available": GROQ_AVAILABLE,
        "groq_key_configured": groq_key_set,
        "timestamp": time.time()
    }

@app.get("/api/status")
async def system_status():
    """Provides detailed system diagnostics and model metadata."""
    engine = get_engine()
    groq_key_set = bool(os.getenv("GROQ_API_KEY"))
    return {
        "status": "operational",
        "app_version": "1.2.0",
        "engine": {
            "loaded": engine.is_loaded,
            "device": str(engine.device),
            "vocabulary_size": len(engine.all_words),
            "intents_count": len(engine.tags),
            "intents": engine.tags
        },
        "groq": {
            "available": GROQ_AVAILABLE,
            "configured": groq_key_set
        },
        "timestamp": time.time()
    }

@app.get("/api/intents")
async def get_intents():
    engine = get_engine()
    return {
        "tags": engine.tags,
        "vocabulary": engine.all_words,
        "total_intents": len(engine.tags)
    }

@app.post("/api/reload")
async def reload_model():
    """Reloads model weights and metadata from disk without restarting server."""
    engine = get_engine()
    success = engine.reload()
    if not success:
        raise HTTPException(status_code=500, detail="Failed to reload model from disk.")
    return {
        "status": "reloaded",
        "vocabulary_size": len(engine.all_words),
        "intents_count": len(engine.tags),
        "timestamp": time.time()
    }

@app.post("/api/chat")
async def chat_endpoint(
    request: ChatRequest,
    req: Request,
    authorization: Optional[str] = Header(None),
    x_admin_token: Optional[str] = Header(None)
):
    admin_mgr = get_admin_manager()
    config = admin_mgr.load_config()

    client_ip = req.client.host if req.client else "127.0.0.1"
    token = authorization or x_admin_token
    is_admin = bool(token and admin_mgr.verify_token(token))

    # 1. Ban & Blacklist Enforcement
    is_banned, ban_reason = admin_mgr.is_banned(request.client_id, client_ip)
    if is_banned and not is_admin:
        return {
            "intent": "banned",
            "confidence": 100.0,
            "response": f"Access Restricted: Your access to VoxAI has been suspended by the administrator. (Reason: {ban_reason})",
            "pytorch_base_response": "Access restricted by administrator.",
            "query": request.text.strip(),
            "engine": "Security Access Control",
            "latency_ms": 0.5,
            "is_banned": True
        }

    # 2. Maintenance mode protection
    is_maintenance = config.get("maintenance_mode", False)

    if is_maintenance and not is_admin:
        return {
            "intent": "maintenance",
            "confidence": 100.0,
            "response": "VoxAI is currently in Maintenance Mode for administrative updates. Please check back shortly.",
            "pytorch_base_response": "System undergoing scheduled maintenance.",
            "query": request.text.strip(),
            "engine": "Maintenance Mode",
            "latency_ms": 1.0
        }

    threshold = config.get("confidence_threshold", 0.50)
    custom_prompt = config.get("custom_system_prompt")

    start_time = time.time()
    try:
        engine = get_engine()
        result = engine.get_response(
            text=request.text.strip(),
            threshold=threshold,
            use_groq=request.use_groq,
            groq_api_key=request.groq_api_key,
            custom_system_prompt=custom_prompt
        )
        latency_ms = round((time.time() - start_time) * 1000, 2)
        result["latency_ms"] = latency_ms

        # Audit log to in-memory admin query stream and categorized user identity profile
        admin_mgr.log_query(
            query=request.text.strip(),
            intent=result.get("intent", "unknown"),
            confidence=result.get("confidence", 0.0),
            latency_ms=latency_ms,
            engine=result.get("engine", "Unknown"),
            bot_response=result.get("response", ""),
            client_id=request.client_id,
            session_id=request.session_id,
            user_agent_label=request.user_agent_label,
            client_ip=client_ip
        )

        return result
    except Exception as e:
        logger.error(f"Error processing chat request: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Internal server error processing request.")

# =============================================================================
# MASTER ENCRYPTED ADMIN COMMAND CENTER API ENDPOINTS
# =============================================================================

@app.post("/api/admin/login")
async def admin_login(body: AdminLoginRequest, request: Request):
    """
    Authenticates master admin with constant-time PBKDF2 verification,
    enforces brute-force lockout, and issues HMAC-SHA256 signed session token.
    """
    client_ip = request.client.host if request.client else "127.0.0.1"
    admin_mgr = get_admin_manager()
    authenticated, token, error_msg = admin_mgr.authenticate_admin(body.password, client_ip=client_ip)

    if not authenticated:
        if error_msg and ("Locked out" in error_msg or "Max attempts" in error_msg):
            raise HTTPException(status_code=429, detail=error_msg)
        raise HTTPException(status_code=401, detail=error_msg or "Invalid admin credentials.")

    return {
        "status": "authenticated",
        "token": token,
        "expires_in": 7200,
        "message": "Security clearance granted. Master admin session established."
    }

@app.post("/api/admin/logout")
async def admin_logout(token: str = Depends(verify_admin_token)):
    """Revokes active admin session token."""
    admin_mgr = get_admin_manager()
    admin_mgr.revoke_token(token)
    return {"status": "logged_out", "message": "Master session securely revoked."}

@app.get("/api/admin/verify")
async def admin_verify_token(token: str = Depends(verify_admin_token)):
    """Verifies whether client has an active, valid cryptographic admin session."""
    return {"status": "valid", "authenticated": True}

@app.get("/api/admin/vitals")
async def admin_system_vitals(token: str = Depends(verify_admin_token)):
    """Returns comprehensive real-time system and PyTorch model diagnostics."""
    admin_mgr = get_admin_manager()
    engine = get_engine()
    vitals = admin_mgr.get_system_vitals()
    vitals["model"] = {
        "is_loaded": engine.is_loaded,
        "device": str(engine.device),
        "vocabulary_size": len(engine.all_words),
        "intents_count": len(engine.tags),
        "tags": engine.tags
    }
    vitals["groq"] = {
        "available": GROQ_AVAILABLE,
        "configured": bool(os.getenv("GROQ_API_KEY"))
    }
    return vitals

@app.get("/api/admin/config")
async def admin_get_config(token: str = Depends(verify_admin_token)):
    """Retrieves current admin hyperparameters, maintenance mode, and settings."""
    admin_mgr = get_admin_manager()
    cfg = admin_mgr.load_config()
    groq_key = os.getenv("GROQ_API_KEY", "")
    masked_key = f"{groq_key[:6]}...{groq_key[-4:]}" if len(groq_key) > 10 else ("Configured" if groq_key else "Not Configured")

    return {
        "confidence_threshold": cfg.get("confidence_threshold", 0.50),
        "maintenance_mode": cfg.get("maintenance_mode", False),
        "custom_system_prompt": cfg.get("custom_system_prompt") or "",
        "default_engine": cfg.get("default_engine", "groq"),
        "groq_configured": bool(groq_key),
        "groq_key_masked": masked_key
    }

@app.post("/api/admin/config")
async def admin_update_config(body: AdminConfigUpdateRequest, token: str = Depends(verify_admin_token)):
    """Updates admin configuration and optional Groq server key."""
    admin_mgr = get_admin_manager()
    cfg = admin_mgr.load_config()

    if body.confidence_threshold is not None:
        cfg["confidence_threshold"] = round(body.confidence_threshold, 2)
    if body.maintenance_mode is not None:
        cfg["maintenance_mode"] = body.maintenance_mode
    if body.custom_system_prompt is not None:
        cfg["custom_system_prompt"] = body.custom_system_prompt.strip() or None
    if body.default_engine is not None:
        cfg["default_engine"] = body.default_engine

    if body.groq_api_key is not None and body.groq_api_key.strip():
        new_key = body.groq_api_key.strip()
        os.environ["GROQ_API_KEY"] = new_key
        admin_mgr.log_security_event("groq_key_updated", "Server-wide Groq API key updated")

    admin_mgr.save_config(cfg)
    admin_mgr.log_security_event("config_updated", "System configuration and thresholds updated")
    return {"status": "updated", "config": cfg}

@app.get("/api/admin/intents")
async def admin_get_intents(token: str = Depends(verify_admin_token)):
    """Retrieves full intents dataset from disk."""
    import json
    if not os.path.exists(INTENTS_PATH):
        raise HTTPException(status_code=404, detail="intents.json dataset file not found.")
    with open(INTENTS_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data

@app.post("/api/admin/intents")
async def admin_save_intents(body: AdminIntentsUpdateRequest, token: str = Depends(verify_admin_token)):
    """
    Validates and persists updated intents dataset to disk,
    ready for hot retraining.
    """
    import json
    # Schema validation
    for i, item in enumerate(body.intents):
        if not isinstance(item, dict) or "tag" not in item or "patterns" not in item or "responses" not in item:
            raise HTTPException(
                status_code=400,
                detail=f"Intent item #{i+1} invalid. Must contain 'tag', 'patterns', and 'responses'."
            )
        if not item["tag"].strip():
            raise HTTPException(status_code=400, detail=f"Intent item #{i+1} has an empty tag.")

    data = {"intents": body.intents}
    temp_path = INTENTS_PATH + ".tmp"
    with open(temp_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(temp_path, INTENTS_PATH)

    admin_mgr = get_admin_manager()
    admin_mgr.log_security_event("intents_saved", f"Intents dataset updated with {len(body.intents)} intents")
    return {"status": "saved", "total_intents": len(body.intents)}

@app.post("/api/admin/retrain")
async def admin_trigger_retrain(token: str = Depends(verify_admin_token)):
    """Initiates asynchronous PyTorch deep neural network retraining in the background."""
    admin_mgr = get_admin_manager()
    success, msg = admin_mgr.trigger_retraining()
    if not success:
        raise HTTPException(status_code=400, detail=msg)
    return {"status": "started", "message": msg}

@app.get("/api/admin/retrain-status")
async def admin_get_retrain_status(token: str = Depends(verify_admin_token)):
    """Polls status of ongoing or completed background retraining job."""
    admin_mgr = get_admin_manager()
    return admin_mgr.get_retrain_status()

@app.post("/api/admin/reload")
async def admin_reload_model(token: str = Depends(verify_admin_token)):
    """Hot-reloads PyTorch model weights and vocabulary from disk."""
    engine = get_engine()
    success = engine.reload()
    if not success:
        raise HTTPException(status_code=500, detail="Failed to reload model from disk.")
    admin_mgr = get_admin_manager()
    admin_mgr.log_security_event("model_hot_reloaded", "Model reloaded from disk into memory")
    return {
        "status": "reloaded",
        "vocabulary_size": len(engine.all_words),
        "intents_count": len(engine.tags),
        "timestamp": time.time()
    }

@app.get("/api/admin/query-logs")
async def admin_get_query_logs(limit: int = 100, token: str = Depends(verify_admin_token)):
    """Returns recent queries stream with intent, confidence, and latency."""
    admin_mgr = get_admin_manager()
    return {"logs": admin_mgr.get_query_logs(limit=limit)}

@app.delete("/api/admin/query-logs")
async def admin_clear_query_logs(token: str = Depends(verify_admin_token)):
    """Clears query stream logs from memory."""
    admin_mgr = get_admin_manager()
    admin_mgr.clear_query_logs()
    return {"status": "cleared", "message": "Query audit logs cleared."}

@app.get("/api/admin/conversations")
async def admin_get_conversations(token: str = Depends(verify_admin_token)):
    """Returns all categorized user conversation profiles with return-visit history."""
    admin_mgr = get_admin_manager()
    return {"users": admin_mgr.get_user_conversations()}

@app.get("/api/admin/conversations/{client_id}")
async def admin_get_user_conversation(client_id: str, token: str = Depends(verify_admin_token)):
    """Returns full categorized chronological chat sessions for a specific user."""
    admin_mgr = get_admin_manager()
    profile = admin_mgr.get_user_conversation_detail(client_id)
    if not profile:
        raise HTTPException(status_code=404, detail="User conversation profile not found.")
    return profile

@app.delete("/api/admin/conversations")
async def admin_clear_all_conversations(token: str = Depends(verify_admin_token)):
    """Clears all stored user conversation profiles and history."""
    admin_mgr = get_admin_manager()
    admin_mgr.clear_user_conversations()
    return {"status": "cleared", "message": "All user conversation records wiped."}

@app.delete("/api/admin/conversations/{client_id}")
async def admin_delete_user_conversation(client_id: str, token: str = Depends(verify_admin_token)):
    """Deletes conversation profile for a single user."""
    admin_mgr = get_admin_manager()
    admin_mgr.delete_user_conversation(client_id)
    return {"status": "deleted", "message": f"User {client_id} history deleted."}

@app.post("/api/admin/change-password")
async def admin_change_password(
    body: AdminPasswordChangeRequest,
    request: Request,
    token: str = Depends(verify_admin_token)
):
    """
    Securely updates the master admin password with PBKDF2 (120,000 rounds)
    and invalidates all previous sessions.
    """
    client_ip = request.client.host if request.client else "127.0.0.1"
    admin_mgr = get_admin_manager()
    success, msg = admin_mgr.change_password(body.old_password, body.new_password, client_ip=client_ip)
    if not success:
        raise HTTPException(status_code=400, detail=msg)
    # Issue a fresh token for the current session
    new_token = admin_mgr.create_session_token()
    return {
        "status": "password_changed",
        "message": msg,
        "new_token": new_token
    }

@app.get("/api/admin/security-logs")
async def admin_security_logs(token: str = Depends(verify_admin_token)):
    """Returns persistent security audit log of logins, failures, and updates."""
    admin_mgr = get_admin_manager()
    cfg = admin_mgr.load_config()
    logs = list(cfg.get("security_logs", []))
    logs.reverse()
    return {"logs": logs}

@app.post("/api/admin/emergency-lock")
async def admin_emergency_lock(token: str = Depends(verify_admin_token)):
    """Emergency protocol: revokes all active session tokens immediately."""
    admin_mgr = get_admin_manager()
    admin_mgr.revoke_all_sessions()
    return {"status": "locked", "message": "Emergency lock executed. All sessions revoked."}

# Public Broadcast Banner Endpoint
@app.get("/api/broadcast")
async def get_public_broadcast():
    """Returns active public broadcast announcement if configured."""
    admin_mgr = get_admin_manager()
    return admin_mgr.get_broadcast()

# Banning and Blacklisting Endpoints
@app.get("/api/admin/banned")
async def admin_get_banned(token: str = Depends(verify_admin_token)):
    """Returns all currently banned visitors and IPs."""
    admin_mgr = get_admin_manager()
    return {"banned": admin_mgr.get_banned_users()}

@app.post("/api/admin/ban")
async def admin_ban_visitor(body: AdminBanRequest, token: str = Depends(verify_admin_token)):
    """Bans a visitor by client ID or IP address, blocking all chat requests."""
    admin_mgr = get_admin_manager()
    entry = admin_mgr.ban_user(body.client_id, body.client_ip, body.reason)
    return {"status": "banned", "entry": entry}

@app.post("/api/admin/unban")
async def admin_unban_visitor(body: AdminUnbanRequest, token: str = Depends(verify_admin_token)):
    """Removes a visitor or IP from the banned blacklist."""
    admin_mgr = get_admin_manager()
    success = admin_mgr.unban_user(body.client_id)
    if not success:
        raise HTTPException(status_code=404, detail="Client ID not found in banned list.")
    return {"status": "unbanned", "client_id": body.client_id}

# Broadcast Management Endpoint
@app.post("/api/admin/broadcast")
async def admin_update_broadcast(body: AdminBroadcastRequest, token: str = Depends(verify_admin_token)):
    """Updates or toggles public live broadcast announcement banner."""
    admin_mgr = get_admin_manager()
    updated = admin_mgr.update_broadcast(body.enabled, body.message)
    return {"status": "updated", "broadcast": updated}

# Admin Intercom / Direct Note Endpoint
@app.post("/api/admin/conversations/{client_id}/intercom")
async def admin_send_intercom(client_id: str, body: AdminIntercomRequest, token: str = Depends(verify_admin_token)):
    """Sends a direct administrative intercom note into a user's session timeline."""
    admin_mgr = get_admin_manager()
    entry = admin_mgr.add_admin_message(client_id, body.message)
    if not entry:
        raise HTTPException(status_code=404, detail="User session not found to dispatch intercom message.")
    return {"status": "sent", "entry": entry}

# AWS Lambda Mangum handler
try:
    from mangum import Mangum
    handler = Mangum(app, lifespan="off")
except ImportError:
    handler = None

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)

