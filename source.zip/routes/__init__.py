"""
VoxAI Routes Package.
"""
